package com.rxjava2.android.samples.model;

/**
 * Created by amitshekhar on 06/02/17.
 */

public class Events {

    private Events() {

    }

    public static class TapEvent {

    }

    public static class AutoEvent {

    }

}
